# Bloc de Notas Minimalista

Bloc de notas simple y rápido (React + Vite + Tailwind).

## Publicar en GitHub Pages
1. Sube todo este contenido a un repositorio de GitHub (rama `main`).
2. Settings → Pages → Source: **GitHub Actions**.
3. Cada push se publica solo.

## Publicar en Cloudflare Pages
- Build command: `npm run build`
- Build output directory: `dist`
- Node version: 22

## Local
`npm install` y luego `npm run dev`
