/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Note,
  DEFAULT_SEED_NOTES,
  STORAGE_KEY,
  createNote,
  updateNoteContent,
  updateNoteTitle,
  deleteNote,
  filterNotes,
} from './utils/notes';
import { Sidebar } from './components/Sidebar';
import { Editor } from './components/Editor';
import { ConfirmModal } from './components/ConfirmModal';
import { Toast } from './components/Toast';

export default function App() {
  // Theme state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('bloc_notas_theme');
      if (savedTheme) return savedTheme === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Notes state
  const [notes, setNotes] = useState<Note[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      } catch (err) {
        console.error('Error loading notes from localStorage:', err);
      }
    }
    return DEFAULT_SEED_NOTES;
  });

  // Active note state
  const [activeNoteId, setActiveNoteId] = useState<string | null>(() => {
    return notes.length > 0 ? notes[0].id : null;
  });

  // Search state
  const [searchQuery, setSearchQuery] = useState('');

  // UI state
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isOpenMobile, setIsOpenMobile] = useState(false);

  // Modals & Notifications
  const [noteToDelete, setNoteToDelete] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{
    text: string;
    actionLabel?: string;
    onAction?: () => void;
  } | null>(null);

  // Stashed note for Undo delete
  const [recentlyDeleted, setRecentlyDeleted] = useState<{
    note: Note;
    index: number;
  } | null>(null);

  // Apply dark mode class to html element
  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem('bloc_notas_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('bloc_notas_theme', 'light');
    }
  }, [isDarkMode]);

  // Persist notes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
    } catch (err) {
      console.error('Error saving notes to localStorage:', err);
    }
  }, [notes]);

  // Active note helper
  const activeNote = useMemo(() => {
    return notes.find((n) => n.id === activeNoteId) || null;
  }, [notes, activeNoteId]);

  // Filtered notes
  const displayedNotes = useMemo(() => {
    return filterNotes(notes, searchQuery);
  }, [notes, searchQuery]);

  // Handle create new note
  const handleNewNote = useCallback(() => {
    const newNote = createNote('', 'Nueva nota');
    setNotes((prev) => [newNote, ...prev]);
    setActiveNoteId(newNote.id);
    setSearchQuery('');
  }, []);

  // Handle note content change
  const handleUpdateContent = useCallback(
    (newContent: string) => {
      if (!activeNoteId) return;
      setNotes((prev) => updateNoteContent(prev, activeNoteId, newContent));
    },
    [activeNoteId]
  );

  // Handle note title change
  const handleUpdateTitle = useCallback(
    (newTitle: string) => {
      if (!activeNoteId) return;
      setNotes((prev) => updateNoteTitle(prev, activeNoteId, newTitle));
    },
    [activeNoteId]
  );

  // Handle deleting note execution
  const executeDeleteNote = useCallback(
    (id: string) => {
      const index = notes.findIndex((n) => n.id === id);
      const target = notes[index];
      if (!target) return;

      const remaining = deleteNote(notes, id);
      setNotes(remaining);

      // Save for Undo
      setRecentlyDeleted({ note: target, index });

      // Update active note selection if the active one was deleted
      if (activeNoteId === id) {
        if (remaining.length > 0) {
          const nextIndex = Math.min(index, remaining.length - 1);
          setActiveNoteId(remaining[nextIndex].id);
        } else {
          setActiveNoteId(null);
        }
      }

      setNoteToDelete(null);

      // Show Undo toast
      setToastMessage({
        text: `Nota "${target.title}" eliminada`,
        actionLabel: 'Deshacer',
        onAction: () => {
          setNotes((current) => {
            const restored = [...current];
            restored.splice(index, 0, target);
            return restored;
          });
          setActiveNoteId(target.id);
          setToastMessage({ text: 'Nota restaurada' });
          setRecentlyDeleted(null);
        },
      });
    },
    [notes, activeNoteId]
  );

  // Request delete confirmation
  const handleRequestDelete = useCallback((id: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setNoteToDelete(id);
  }, []);

  // Clear text inside active note
  const handleClearText = useCallback(() => {
    if (!activeNoteId || !activeNote) return;
    const oldContent = activeNote.content;
    handleUpdateContent('');
    setToastMessage({
      text: 'Texto limpiado',
      actionLabel: 'Deshacer',
      onAction: () => {
        handleUpdateContent(oldContent);
        setToastMessage(null);
      },
    });
  }, [activeNoteId, activeNote, handleUpdateContent]);

  // Copy text to clipboard
  const handleCopyText = useCallback(() => {
    if (!activeNote) return;
    const textToCopy = `${activeNote.title}\n\n${activeNote.content}`;
    navigator.clipboard
      .writeText(textToCopy)
      .then(() => {
        setToastMessage({ text: 'Texto copiado al portapapeles' });
      })
      .catch(() => {
        setToastMessage({ text: 'No se pudo copiar el texto' });
      });
  }, [activeNote]);

  // Download note as .txt
  const handleDownloadTxt = useCallback(() => {
    if (!activeNote) return;
    const element = document.createElement('a');
    const file = new Blob([`${activeNote.title}\n\n${activeNote.content}`], {
      type: 'text/plain;charset=utf-8',
    });
    const filename = `${(activeNote.title || 'nota').toLowerCase().replace(/[^a-z0-9]/gi, '_')}.txt`;
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    setToastMessage({ text: `Descargado como ${filename}` });
  }, [activeNote]);

  // Keyboard shortcuts listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+N or Cmd+N for new note
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        handleNewNote();
      }
      // Ctrl+Shift+D or Cmd+Shift+D to delete active note
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'd') {
        if (activeNoteId) {
          e.preventDefault();
          setNoteToDelete(activeNoteId);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNewNote, activeNoteId]);

  // Auto-hide toast after 4 seconds
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const targetDeleteNote = useMemo(() => {
    return notes.find((n) => n.id === noteToDelete) || null;
  }, [notes, noteToDelete]);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-neutral-50 dark:bg-neutral-950 font-sans text-neutral-900 dark:text-neutral-100">
      {/* Sidebar */}
      {isSidebarOpen && (
        <Sidebar
          notes={displayedNotes}
          activeNoteId={activeNoteId}
          onSelectNote={(id) => setActiveNoteId(id)}
          onNewNote={handleNewNote}
          onDeleteNote={(id, e) => handleRequestDelete(id, e)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          isOpenMobile={isOpenMobile}
          onCloseMobile={() => setIsOpenMobile(false)}
        />
      )}

      {/* Editor Main Canvas */}
      <Editor
        note={activeNote}
        onUpdateContent={handleUpdateContent}
        onUpdateTitle={handleUpdateTitle}
        onDeleteNote={() => activeNoteId && setNoteToDelete(activeNoteId)}
        onClearText={handleClearText}
        onCopyText={handleCopyText}
        onDownloadTxt={handleDownloadTxt}
        onNewNote={handleNewNote}
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
        onOpenMobileSidebar={() => setIsOpenMobile(true)}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode((prev) => !prev)}
      />

      {/* Confirm Deletion Modal */}
      <ConfirmModal
        isOpen={!!noteToDelete}
        title="¿Eliminar esta nota?"
        message={`Estás a punto de borrar "${targetDeleteNote?.title || 'esta nota'}". Podrás deshacer la acción inmediatamente si lo deseas.`}
        confirmLabel="Eliminar nota"
        cancelLabel="Cancelar"
        onConfirm={() => {
          if (noteToDelete) {
            executeDeleteNote(noteToDelete);
          }
        }}
        onCancel={() => setNoteToDelete(null)}
      />

      {/* Action Toast */}
      {toastMessage && (
        <Toast
          message={toastMessage.text}
          actionLabel={toastMessage.actionLabel}
          onAction={toastMessage.onAction}
          onClose={() => setToastMessage(null)}
        />
      )}
    </div>
  );
}
