import React, { useId } from 'react';
import { Plus, Search, Trash2, FileText, X } from 'lucide-react';
import { Note, formatDateLabel, calculateStats } from '../utils/notes';

interface SidebarProps {
  notes: Note[];
  activeNoteId: string | null;
  onSelectNote: (id: string) => void;
  onNewNote: () => void;
  onDeleteNote: (id: string, e: React.MouseEvent) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  notes,
  activeNoteId,
  onSelectNote,
  onNewNote,
  onDeleteNote,
  searchQuery,
  onSearchChange,
  isOpenMobile,
  onCloseMobile,
}) => {
  const searchInputId = useId();

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          aria-hidden="true"
          className="fixed inset-0 z-30 bg-black/30 md:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-72 md:w-80 shrink-0 flex flex-col bg-neutral-100/80 dark:bg-neutral-900/80 md:bg-neutral-100/50 md:dark:bg-neutral-900/40 border-r border-neutral-200 dark:border-neutral-800 transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-200/80 dark:border-neutral-800/80 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-neutral-800 dark:text-neutral-200" />
              <h1 className="text-base font-semibold tracking-tight text-neutral-900 dark:text-neutral-100">
                Bloc de Notas
              </h1>
            </div>
            {/* Mobile close button */}
            <button
              onClick={onCloseMobile}
              aria-label="Cerrar barra lateral"
              className="md:hidden p-1.5 text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 rounded-md"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* New note button */}
          <button
            onClick={() => {
              onNewNote();
              if (isOpenMobile) onCloseMobile();
            }}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-white rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400 cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Nueva nota</span>
          </button>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none" />
            <input
              id={searchInputId}
              type="text"
              placeholder="Buscar notas..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-8 py-1.5 text-xs bg-white dark:bg-neutral-950/60 border border-neutral-200 dark:border-neutral-800 rounded-md text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:border-neutral-400 dark:focus:border-neutral-600 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                aria-label="Limpiar búsqueda"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Note list */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {notes.length === 0 ? (
            <div className="py-12 px-4 text-center">
              <p className="text-sm text-neutral-500 dark:text-neutral-400">
                {searchQuery ? 'No se encontraron notas' : 'No tienes notas creadas'}
              </p>
              {searchQuery ? (
                <button
                  onClick={() => onSearchChange('')}
                  className="mt-2 text-xs text-neutral-700 dark:text-neutral-300 underline"
                >
                  Borrar filtro
                </button>
              ) : (
                <button
                  onClick={onNewNote}
                  className="mt-2 text-xs font-medium text-neutral-900 dark:text-neutral-100 underline hover:opacity-80"
                >
                  Crear tu primera nota
                </button>
              )}
            </div>
          ) : (
            notes.map((note) => {
              const isActive = note.id === activeNoteId;
              const stats = calculateStats(note.content);
              const snippet = note.content
                ? note.content
                    .split('\n')
                    .filter((line) => line.trim())
                    .slice(1, 3)
                    .join(' ')
                    .trim() || 'Sin contenido adicional'
                : 'Nota vacía';

              return (
                <div
                  key={note.id}
                  onClick={() => {
                    onSelectNote(note.id);
                    if (isOpenMobile) onCloseMobile();
                  }}
                  className={`group relative flex flex-col gap-1 p-3 rounded-lg text-left cursor-pointer transition-all ${
                    isActive
                      ? 'bg-white dark:bg-neutral-800/80 shadow-xs border border-neutral-200/80 dark:border-neutral-700/80'
                      : 'hover:bg-neutral-200/50 dark:hover:bg-neutral-800/40 border border-transparent'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3
                      className={`text-sm font-medium line-clamp-1 truncate ${
                        isActive
                          ? 'text-neutral-900 dark:text-neutral-100 font-semibold'
                          : 'text-neutral-800 dark:text-neutral-200'
                      }`}
                    >
                      {note.title || 'Nota sin título'}
                    </h3>

                    {/* Delete button on hover / active */}
                    <button
                      type="button"
                      onClick={(e) => onDeleteNote(note.id, e)}
                      aria-label={`Eliminar ${note.title || 'nota'}`}
                      className="opacity-0 group-hover:opacity-100 md:opacity-0 focus:opacity-100 p-1 text-neutral-400 hover:text-red-600 dark:hover:text-red-400 rounded transition-all focus:outline-none"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-2 leading-relaxed">
                    {snippet}
                  </p>

                  <div className="mt-1 flex items-center gap-2 text-[11px] text-neutral-400 dark:text-neutral-500">
                    <span>{formatDateLabel(note.updatedAt)}</span>
                    <span aria-hidden="true">·</span>
                    <span>{stats.words} {stats.words === 1 ? 'palabra' : 'palabras'}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-neutral-200/80 dark:border-neutral-800/80 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
          <span>{notes.length} {notes.length === 1 ? 'nota' : 'notas'}</span>
          <span className="text-[11px] text-neutral-400">Atajo: Ctrl+N</span>
        </div>
      </aside>
    </>
  );
};
