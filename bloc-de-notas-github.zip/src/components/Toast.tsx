import React from 'react';

interface ToastProps {
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({
  message,
  actionLabel,
  onAction,
  onClose,
}) => {
  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-4 py-3 bg-neutral-900 text-neutral-100 dark:bg-neutral-100 dark:text-neutral-900 rounded-lg shadow-lg text-sm border border-neutral-700/50 dark:border-neutral-200/50 transition-all duration-200"
    >
      <span>{message}</span>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="font-medium underline hover:opacity-80 transition-opacity focus:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
        >
          {actionLabel}
        </button>
      )}
      <button
        onClick={onClose}
        aria-label="Cerrar notificación"
        className="ml-2 text-neutral-400 hover:text-neutral-200 dark:text-neutral-600 dark:hover:text-neutral-900 transition-colors p-1"
      >
        ✕
      </button>
    </div>
  );
};
