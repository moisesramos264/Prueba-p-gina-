import React, { useRef, useEffect } from 'react';
import {
  Copy,
  Download,
  Trash2,
  Eraser,
  PanelLeftClose,
  PanelLeft,
  Sun,
  Moon,
  Menu,
  Check,
  Plus,
} from 'lucide-react';
import { Note, calculateStats, formatDateLabel } from '../utils/notes';

interface EditorProps {
  note: Note | null;
  onUpdateContent: (content: string) => void;
  onUpdateTitle: (title: string) => void;
  onDeleteNote: () => void;
  onClearText: () => void;
  onCopyText: () => void;
  onDownloadTxt: () => void;
  onNewNote: () => void;
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  onOpenMobileSidebar: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

export const Editor: React.FC<EditorProps> = ({
  note,
  onUpdateContent,
  onUpdateTitle,
  onDeleteNote,
  onClearText,
  onCopyText,
  onDownloadTxt,
  onNewNote,
  isSidebarOpen,
  onToggleSidebar,
  onOpenMobileSidebar,
  isDarkMode,
  onToggleTheme,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-focus textarea when note changes
  useEffect(() => {
    if (note) {
      textareaRef.current?.focus();
    }
  }, [note?.id]);

  if (!note) {
    return (
      <main className="flex-1 flex flex-col h-screen bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 overflow-hidden">
        {/* Top bar */}
        <header className="h-14 px-4 md:px-6 flex items-center justify-between border-b border-neutral-200/80 dark:border-neutral-800/80">
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenMobileSidebar}
              aria-label="Abrir menú de notas"
              className="md:hidden p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <button
              onClick={onToggleSidebar}
              aria-label={isSidebarOpen ? 'Ocultar panel lateral' : 'Mostrar panel lateral'}
              className="hidden md:flex p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
              title={isSidebarOpen ? 'Ocultar barra lateral' : 'Mostrar barra lateral'}
            >
              {isSidebarOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onToggleTheme}
              aria-label={isDarkMode ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}
              className="p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
              title={isDarkMode ? 'Modo claro' : 'Modo oscuro'}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* Empty state */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-md mx-auto">
          <div className="w-12 h-12 rounded-full bg-neutral-100 dark:bg-neutral-900 flex items-center justify-center text-neutral-400 dark:text-neutral-500 mb-4">
            <Plus className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-semibold text-neutral-900 dark:text-neutral-100">
            Ninguna nota seleccionada
          </h2>
          <p className="mt-2 text-sm text-neutral-500 dark:text-neutral-400">
            Crea una nueva nota para empezar a escribir o selecciona una existente de la lista.
          </p>
          <button
            onClick={onNewNote}
            className="mt-6 flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-white rounded-lg transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Crear nueva nota</span>
          </button>
        </div>
      </main>
    );
  }

  const stats = calculateStats(note.content);

  return (
    <main className="flex-1 flex flex-col h-screen bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 overflow-hidden">
      {/* Top action bar */}
      <header className="h-14 px-4 md:px-8 flex items-center justify-between border-b border-neutral-200/80 dark:border-neutral-800/80 shrink-0">
        <div className="flex items-center gap-2">
          {/* Mobile menu toggle */}
          <button
            onClick={onOpenMobileSidebar}
            aria-label="Abrir menú de notas"
            className="md:hidden p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Desktop sidebar toggle for focus mode */}
          <button
            onClick={onToggleSidebar}
            aria-label={isSidebarOpen ? 'Ocultar panel lateral' : 'Mostrar panel lateral'}
            className="hidden md:flex p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
            title={isSidebarOpen ? 'Ocultar panel lateral (modo zen)' : 'Mostrar panel lateral'}
          >
            {isSidebarOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
          </button>

          {/* Subtle Saved status */}
          <div className="hidden sm:flex items-center gap-1.5 ml-2 text-xs text-neutral-400 dark:text-neutral-500 font-medium">
            <Check className="w-3.5 h-3.5 text-emerald-500" />
            <span>Guardado</span>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1 md:gap-2">
          {/* Copy text */}
          <button
            type="button"
            onClick={onCopyText}
            aria-label="Copiar texto de la nota"
            className="p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
            title="Copiar texto"
          >
            <Copy className="w-4 h-4" />
          </button>

          {/* Download txt */}
          <button
            type="button"
            onClick={onDownloadTxt}
            aria-label="Descargar nota como archivo de texto"
            className="p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
            title="Descargar como .txt"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Clear text */}
          <button
            type="button"
            onClick={onClearText}
            aria-label="Limpiar todo el texto de la nota"
            className="p-2 text-neutral-600 hover:text-amber-600 dark:text-neutral-400 dark:hover:text-amber-400 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
            title="Limpiar contenido"
          >
            <Eraser className="w-4 h-4" />
          </button>

          {/* Delete note */}
          <button
            type="button"
            onClick={onDeleteNote}
            aria-label="Borrar nota"
            className="p-2 text-neutral-600 hover:text-red-600 dark:text-neutral-400 dark:hover:text-red-400 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
            title="Borrar nota"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          <div className="w-px h-4 bg-neutral-200 dark:bg-neutral-800 mx-1" aria-hidden="true" />

          {/* Dark mode toggle */}
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={isDarkMode ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}
            className="p-2 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer"
            title={isDarkMode ? 'Modo claro' : 'Modo oscuro'}
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Note Editor Area */}
      <div className="flex-1 flex flex-col px-4 md:px-12 lg:px-24 py-6 overflow-y-auto max-w-4xl w-full mx-auto">
        {/* Title input */}
        <input
          type="text"
          value={note.title}
          onChange={(e) => onUpdateTitle(e.target.value)}
          placeholder="Título de la nota..."
          aria-label="Título de la nota"
          className="w-full text-2xl md:text-3xl font-bold tracking-tight bg-transparent border-none outline-none text-neutral-900 dark:text-neutral-100 placeholder-neutral-300 dark:placeholder-neutral-700 pb-2 focus:ring-0"
        />

        {/* Content textarea */}
        <textarea
          ref={textareaRef}
          value={note.content}
          onChange={(e) => onUpdateContent(e.target.value)}
          placeholder="Escribe tu texto aquí... (editar, agregar o borrar)"
          aria-label="Contenido de la nota"
          className="flex-1 w-full mt-4 text-base md:text-lg leading-relaxed bg-transparent border-none outline-none resize-none text-neutral-800 dark:text-neutral-200 placeholder-neutral-300 dark:placeholder-neutral-700 focus:ring-0 font-normal min-h-[300px]"
          spellCheck={true}
        />
      </div>

      {/* Bottom Status Bar */}
      <footer className="h-10 px-4 md:px-8 border-t border-neutral-200/80 dark:border-neutral-800/80 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 shrink-0 select-none">
        <div className="flex items-center gap-3">
          <span>{stats.words} {stats.words === 1 ? 'palabra' : 'palabras'}</span>
          <span aria-hidden="true">·</span>
          <span>{stats.chars} caracteres</span>
          <span aria-hidden="true" className="hidden sm:inline">·</span>
          <span className="hidden sm:inline">{stats.lines} {stats.lines === 1 ? 'línea' : 'líneas'}</span>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-neutral-400 dark:text-neutral-500">
          <span>Editado {formatDateLabel(note.updatedAt)}</span>
        </div>
      </footer>
    </main>
  );
};
