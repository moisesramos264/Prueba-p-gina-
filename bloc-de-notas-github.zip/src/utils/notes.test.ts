import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createNote,
  updateNoteContent,
  updateNoteTitle,
  deleteNote,
  getDerivedTitle,
  calculateStats,
  filterNotes,
  DEFAULT_SEED_NOTES,
  Note,
} from './notes.ts';

test('createNote should create a valid note with unique id and timestamps', () => {
  const note = createNote('Primera línea de prueba\nSegunda línea de contenido');
  assert.ok(note.id.startsWith('note_'));
  assert.equal(note.title, 'Primera línea de prueba');
  assert.equal(note.content, 'Primera línea de prueba\nSegunda línea de contenido');
  assert.ok(note.createdAt > 0);
  assert.equal(note.createdAt, note.updatedAt);
});

test('getDerivedTitle should handle empty and multi-line content', () => {
  assert.equal(getDerivedTitle(''), 'Nota sin título');
  assert.equal(getDerivedTitle('   \n  '), 'Nota sin título');
  assert.equal(getDerivedTitle('# Gran Encabezado\nContenido abajo'), 'Gran Encabezado');
  assert.equal(getDerivedTitle('Texto corto'), 'Texto corto');
});

test('updateNoteContent should modify content and update title and timestamp', () => {
  const initial = [createNote('Contenido original')];
  const id = initial[0].id;
  const updated = updateNoteContent(initial, id, 'Nuevo título actualizado\nMás texto');

  assert.equal(updated.length, 1);
  assert.equal(updated[0].content, 'Nuevo título actualizado\nMás texto');
  assert.equal(updated[0].title, 'Nuevo título actualizado');
  assert.ok(updated[0].updatedAt >= initial[0].updatedAt);
});

test('updateNoteTitle should explicitly change title', () => {
  const initial = [createNote('Contenido')];
  const id = initial[0].id;
  const updated = updateNoteTitle(initial, id, 'Título manual');

  assert.equal(updated[0].title, 'Título manual');
});

test('deleteNote should remove the note by id', () => {
  const notes: Note[] = [...DEFAULT_SEED_NOTES];
  const targetId = notes[0].id;
  const remaining = deleteNote(notes, targetId);

  assert.equal(remaining.length, notes.length - 1);
  assert.ok(!remaining.some((n) => n.id === targetId));
});

test('calculateStats should return correct word, char and line counts', () => {
  const statsEmpty = calculateStats('');
  assert.equal(statsEmpty.words, 0);
  assert.equal(statsEmpty.chars, 0);
  assert.equal(statsEmpty.lines, 0);

  const sampleText = 'Hola mundo hermoso\nSegunda línea';
  const stats = calculateStats(sampleText);
  assert.equal(stats.words, 5);
  assert.equal(stats.lines, 2);
  assert.equal(stats.chars, sampleText.length);
});

test('filterNotes should filter by title or content query case-insensitively', () => {
  const notes: Note[] = [
    createNote('Comprar manzanas rojas', 'Compras'),
    createNote('Reunión urgente de equipo', 'Trabajo'),
  ];

  const result1 = filterNotes(notes, 'manzanas');
  assert.equal(result1.length, 1);
  assert.equal(result1[0].title, 'Compras');

  const result2 = filterNotes(notes, 'TRABAJO');
  assert.equal(result2.length, 1);
  assert.equal(result2[0].title, 'Trabajo');

  const resultEmpty = filterNotes(notes, '');
  assert.equal(resultEmpty.length, 2);
});
