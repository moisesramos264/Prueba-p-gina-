export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  updatedAt: number;
}

export const STORAGE_KEY = 'minimalist_notes_app_data_v1';

/**
 * Derives a clean title from the note content (first non-empty line),
 * or returns the default fallback.
 */
export function getDerivedTitle(content: string, fallback: string = 'Nota sin título'): string {
  if (!content || !content.trim()) {
    return fallback;
  }
  const firstLine = content.trim().split('\n')[0].trim();
  // Strip leading markdown headers like '# ' or '## ' if any
  const cleaned = firstLine.replace(/^#+\s*/, '');
  if (!cleaned) {
    return fallback;
  }
  return cleaned.length > 50 ? `${cleaned.slice(0, 50)}...` : cleaned;
}

/**
 * Creates a new note object with timestamp and unique id.
 */
export function createNote(initialContent: string = '', initialTitle?: string): Note {
  const now = Date.now();
  const id = `note_${now}_${Math.random().toString(36).substring(2, 9)}`;
  const title = initialTitle || getDerivedTitle(initialContent);

  return {
    id,
    title,
    content: initialContent,
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Updates a note's content and auto-updates its updatedAt timestamp.
 * Auto-derives title from content only if title is empty, 'Nueva nota', or was previously derived.
 */
export function updateNoteContent(notes: Note[], id: string, newContent: string): Note[] {
  const now = Date.now();
  return notes.map((note) => {
    if (note.id !== id) return note;
    const oldDerived = getDerivedTitle(note.content);
    const shouldAutoDerive =
      !note.title ||
      note.title === 'Nueva nota' ||
      note.title === 'Nota sin título' ||
      note.title === oldDerived;

    const nextTitle = shouldAutoDerive ? getDerivedTitle(newContent) : note.title;

    return {
      ...note,
      content: newContent,
      title: nextTitle,
      updatedAt: now,
    };
  });
}

/**
 * Explicitly updates a note's title.
 */
export function updateNoteTitle(notes: Note[], id: string, newTitle: string): Note[] {
  const now = Date.now();
  return notes.map((note) => {
    if (note.id !== id) return note;
    return {
      ...note,
      title: newTitle.trim() || 'Nota sin título',
      updatedAt: now,
    };
  });
}

/**
 * Deletes a note by its ID.
 */
export function deleteNote(notes: Note[], id: string): Note[] {
  return notes.filter((note) => note.id !== id);
}

/**
 * Computes word, char, and line counts.
 */
export function calculateStats(text: string): {
  words: number;
  chars: number;
  lines: number;
  readTimeMinutes: number;
} {
  const chars = text.length;
  const lines = text ? text.split('\n').length : 0;
  const trimmed = text.trim();
  const words = trimmed === '' ? 0 : trimmed.split(/\s+/).length;
  const readTimeMinutes = Math.max(1, Math.ceil(words / 200));

  return {
    words,
    chars,
    lines,
    readTimeMinutes,
  };
}

/**
 * Filters notes based on a search term across title and content.
 */
export function filterNotes(notes: Note[], query: string): Note[] {
  if (!query || !query.trim()) return notes;
  const q = query.toLowerCase().trim();
  return notes.filter(
    (n) => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q)
  );
}

/**
 * Formats a timestamp into a simple readable Spanish relative/absolute date.
 */
export function formatDateLabel(timestamp: number): string {
  const now = Date.now();
  const diffMinutes = Math.floor((now - timestamp) / (1000 * 60));

  if (diffMinutes < 1) return 'Hace un momento';
  if (diffMinutes < 60) return `Hace ${diffMinutes} min`;

  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) return `Hace ${diffHours} h`;

  const date = new Date(timestamp);
  return date.toLocaleDateString('es-ES', {
    day: 'numeric',
    month: 'short',
  });
}

/**
 * Initial seed notes if the user arrives with empty storage.
 */
export const DEFAULT_SEED_NOTES: Note[] = [
  {
    id: 'seed-1',
    title: 'Bienvenido a tu Bloc de Notas',
    content: `Bienvenido a tu Bloc de Notas minimalista.

Esta herramienta está pensada para ser rápida, limpia y sin distracciones:
- Escribe directamente lo que piensas.
- Agrega nuevas notas con el botón "+ Nueva nota" o con el atajo Ctrl+N / Cmd+N.
- Edita el texto cuando lo desees; los cambios se guardan al instante.
- Borra notas individuales o limpia el contenido cuando ya no lo necesites.

Disfruta de la simplicidad al escribir.`,
    createdAt: Date.now() - 3600000,
    updatedAt: Date.now() - 3600000,
  },
  {
    id: 'seed-2',
    title: 'Lista de ideas pendientes',
    content: `Lista de ideas pendientes

1. Terminar borrador del proyecto
2. Comprar café en grano
3. Leer 15 páginas antes de dormir
4. Revisar notas de la reunión de diseño`,
    createdAt: Date.now() - 7200000,
    updatedAt: Date.now() - 7200000,
  },
];
